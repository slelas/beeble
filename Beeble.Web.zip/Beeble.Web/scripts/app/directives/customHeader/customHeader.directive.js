﻿angular.module('myApp').directive('customheader', function () {
	return {
		templateUrl: 'scripts/app/directives/customHeader/customHeader.template.html'
	};
});