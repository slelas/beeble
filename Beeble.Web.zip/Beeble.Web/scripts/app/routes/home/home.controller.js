var app = angular.module('myApp');

app.controller("homeController", HomeControllerFunction);

function HomeControllerFunction($scope, $state) {
    
}